<?php
	//SQL server information, this is pretty self explanitory based on the variable names. 
	//$host == Hostname, the ip address/website name of your SQL server.
	include("dbconfig.php");
	//Your steamAPI key, this is required and can be applied for here: http://steamcommunity.com/dev
	$steam_api = "";
	
	//Plese insert the home directory for this personal Loading screen installation.
	$home = "";
	
	//Please insert your base website address.
	$website = "";
	
	//Please insert your community forum url, this is seen as a link in the account page.
	$forum_url = "";
	
	session_start();
?>