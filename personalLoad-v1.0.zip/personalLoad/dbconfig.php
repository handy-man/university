<?php 
//Insert your hostname to your mysql database.
$host = "";
//Insert the username used to connect to your database.
$user = "";
//Insert the password used to connect to your mysql database.
$pass = "";
//Insert the name of the database name here
$dbname = "";
?>