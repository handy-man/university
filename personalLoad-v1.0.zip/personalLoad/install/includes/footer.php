<?php
/*------------------------\
|        TTT STATS        |
|	       Beta           |
|=========================|
|© 2013 SNGaming.org      |
|	All Rights Reserved   |
|=========================|
| 	Website printout      |
| 	   beta testing       |
| 	   by Handy_man       |
\------------------------*/				
?>
				<div class="clearfooter">
				</div>
				</div>
			
			
				<div class="siteFooter">
				<div class="center">
					<p>Handy_man is contactable via e-mail @ administrator@thehiddennation.com</p>
				</div>
				</div>
		</body>
</html>