<?PHP
include("./includes/header.php");
?>
<div id="primary_content">
This is the installation page for the script PersonalLoad relased for sale at <a href="http://coderhire.com">Coderhire</a></br></br>
If you did not purchase this script from CoderHire please be generous and do so.
</div>
<form action="db.php" method="POST" enctype="multipart/form-data">
<h3 class="center">PersonalLoad installation starting.</h3>
<div align="center">
<button class='button' onclick="" type='submit'>Ok</button></div>



<?PHP include("./includes/footer.php")?>